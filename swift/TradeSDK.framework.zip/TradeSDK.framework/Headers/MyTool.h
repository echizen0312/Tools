//
//  MyTool.h
//  LimitIM
//
//  Created by feifei on 13-11-19.
//  Copyright (c) 2013年 feifei. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>

@interface MyTool : NSObject
    
typedef void (^HttpBlock)(NSData *result, NSError *error);

+ (NSData *)httpGet:(NSString *)url;
+ (void)httpPost:(NSString *)param url:(NSString *)url completed:(HttpBlock)completedBlock;

@end
